'use client'

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Send, X, GripVertical } from 'lucide-react'

interface ImageItem {
  id: string
  url: string
  name: string
  order: number
}

export default function Home() {
  const [selectedImages, setSelectedImages] = useState<ImageItem[]>([
    {
      id: 'demo-1',
      url: '/whatsapp-demo.png',
      name: 'whatsapp-demo.png',
      order: 0
    },
    {
      id: 'demo-2',
      url: '/drag-drop-demo.png',
      name: 'drag-drop-demo.png',
      order: 1
    }
  ])
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dragItem = useRef<number | null>(null)
  const dragOverItem = useRef<number | null>(null)

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files) return

    const newImages: ImageItem[] = []
    Array.from(files).forEach((file, index) => {
      if (file.type.startsWith('image/')) {
        const url = URL.createObjectURL(file)
        newImages.push({
          id: `${Date.now()}-${index}`,
          url,
          name: file.name,
          order: selectedImages.length + index
        })
      }
    })

    setSelectedImages(prev => [...prev, ...newImages])
    setIsImageDialogOpen(false)
  }

  const removeImage = (id: string) => {
    setSelectedImages(prev => prev.filter(img => img.id !== id))
  }

  const handleDragStart = (index: number) => {
    dragItem.current = index
  }

  const handleDragEnter = (index: number) => {
    dragOverItem.current = index
  }

  const handleDragEnd = () => {
    if (dragItem.current === null || dragOverItem.current === null) return

    const newImages = [...selectedImages]
    const draggedItem = newImages[dragItem.current]
    
    // Remove dragged item
    newImages.splice(dragItem.current, 1)
    // Insert at new position
    newImages.splice(dragOverItem.current, 0, draggedItem)
    
    // Update order
    const updatedImages = newImages.map((img, index) => ({
      ...img,
      order: index
    }))

    setSelectedImages(updatedImages)
    dragItem.current = null
    dragOverItem.current = null
  }

  const handleSendImages = () => {
    if (selectedImages.length === 0) return
    
    // Simulate sending images
    alert(`Enviando ${selectedImages.length} imágenes en orden:\n${selectedImages.map((img, index) => `${index + 1}. ${img.name}`).join('\n')}`)
    
    // Clear selected images
    setSelectedImages([])
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
        {/* WhatsApp-like header */}
        <div className="bg-green-500 text-white p-4">
          <h1 className="text-xl font-semibold">WhatsApp</h1>
          <p className="text-sm opacity-90">Reorganiza tus imágenes antes de enviar</p>
        </div>

        {/* Main content */}
        <div className="p-4 space-y-4">
          {/* Image preview area */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Imágenes seleccionadas ({selectedImages.length})</span>
                <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar imágenes
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Seleccionar imágenes</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600">
                        Selecciona las imágenes que deseas enviar. Podrás reordenarlas después.
                      </p>
                      <Button 
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Elegir de la galería
                      </Button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </div>
                  </DialogContent>
                </Dialog>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedImages.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No hay imágenes seleccionadas</p>
                  <p className="text-sm">Haz clic en "Agregar imágenes" para comenzar</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600">
                      Arrastra y suelta para reordenar las imágenes:
                    </p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedImages([])}
                      className="text-xs"
                    >
                      Limpiar todas
                    </Button>
                  </div>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {selectedImages
                      .sort((a, b) => a.order - b.order)
                      .map((image, index) => (
                        <div
                          key={image.id}
                          draggable
                          onDragStart={() => handleDragStart(index)}
                          onDragEnter={() => handleDragEnter(index)}
                          onDragEnd={handleDragEnd}
                          onDragOver={(e) => e.preventDefault()}
                          className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200 cursor-move hover:bg-gray-100 transition-colors"
                        >
                          <GripVertical className="w-4 h-4 text-gray-400 flex-shrink-0" />
                          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                            <img
                              src={image.url}
                              alt={image.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{image.name}</p>
                            <Badge variant="secondary" className="text-xs">
                              Orden: {index + 1}
                            </Badge>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeImage(image.id)}
                            className="flex-shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Send button */}
          <Button
            onClick={handleSendImages}
            disabled={selectedImages.length === 0}
            className="w-full bg-green-500 hover:bg-green-600"
          >
            <Send className="w-4 h-4 mr-2" />
            Enviar {selectedImages.length} imagen{selectedImages.length !== 1 ? 'es' : ''}
          </Button>

          {/* Instructions */}
          <div className="text-xs text-gray-500 space-y-1">
            <p>• Las imágenes de demostración están precargadas para que puedas probar la función</p>
            <p>• Haz clic en "Agregar imágenes" para seleccionar desde tu galería</p>
            <p>• Arrastra las imágenes para reordenarlas antes de enviar</p>
            <p>• Usa el botón × para eliminar imágenes individuales</p>
            <p>• Usa "Limpiar todas" para empezar desde cero</p>
          </div>
        </div>
      </div>
    </div>
  )
}